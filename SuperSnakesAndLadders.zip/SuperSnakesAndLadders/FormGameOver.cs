﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SuperSnakesAndLadders
{
    public partial class FormGameOver : Form
    {
        private SoundPlayer _playerOver = null;
        public FormGameOver()
        {
            Application.OpenForms["FormGame"].Hide();
            InitializeComponent();
            _playerOver = new SoundPlayer(Properties.Resources.cry_for_lose);
        }

        private void buttonEnd_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void buttonPlayAgain_Click(object sender, EventArgs e)
        {
            FormName name = new FormName();
            name.Show();
        }

        private void FormGameOver_Load(object sender, EventArgs e)
        {
            _playerOver.Play();
        }
    }
}
