﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SuperSnakesAndLadders
{
    public partial class FormWin : Form
    {
        public String txt;
        private SoundPlayer _playerWin = null;
        public FormWin()
        {
            InitializeComponent();
            Application.OpenForms["FormGame"].Hide();
            _playerWin = new SoundPlayer(Properties.Resources.cheer_up_);
        }

        private void buttonEnd_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void buttonPlayAgain_Click(object sender, EventArgs e)
        {
            FormName name = new FormName();
            name.Show();
        }

        private void FormWin_Load(object sender, EventArgs e)
        {
            labelName.Text = txt;
            _playerWin.Play();
        }
    }
}
