﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SuperSnakesAndLadders
{
    class Snake
    {
        private int _pox;
        private int _poy;
        private int _pod;
        private int _poox;
        private int _pooy;
        public int pod { get { return _pod; } set { _pod = value; } }
        public int pox { get { return _pox; } set { _pox = value; } }
        public int poy { get { return _poy; } set { _poy = value; } }
        public int poox { get { return _poox; } set { _poox = value; } }
        public int pooy { get { return _pooy; } set { _pooy = value; } }
        public Snake() { }

        public Snake(int ipoox, int ipooy)
        {
            poox = ipoox;
            pooy = ipooy;

        }
        public void podice2(int y)
        {
            pod = y;
            qmove();
        }
        public void qmove()
        {
            if (pod == 18)
            {
                pox = poox + 46 * 2;
                poy = pooy - 47;
            }
            else if (pod == 10)
            {
                pox = poox + 46 * 9;
                poy = pooy;
            }
            else if (pod == 15)
            {
                pox = poox + 46 * 5;
                poy = pooy - 47;
            }
            else if (pod == 21)
            {
                pox = poox + 46;
                poy = pooy - 47 * 2;
            }
            else if (pod == 43)
            {
                pox = poox + 46 * 2;
                poy = pooy - 47 * 4;
            }

        }
        /*public int CheckSnake(int map, PictureBox player)
        {
            if (map == 1)
            {
                if (player.Location == new Point(386, 337))
                {
                    player.Location = new Point(432, 431);
                }
                else if (player.Location == new Point(18, 290))
                {
                    player.Location = new Point(18, 337);
                }
                
            }
            return map;
        }*/





    }
}
