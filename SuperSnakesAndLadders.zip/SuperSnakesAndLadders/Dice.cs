﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SuperSnakesAndLadders
{
    class Dice
    {
       
        private int _nDice;
        public Dice()
        {
            
            _nDice = 0;
        }
        public Dice(int nDice)
        {
            
            _nDice= nDice;
        }

        public int PointDice
        {
            get { return _nDice; }
            set { _nDice = value; }
        }
        public static int rolldic2(PictureBox px)
        {
            Random rand = new Random();
            int PointDice = rand.Next(1, 7);
            switch (PointDice)
            {
                case 1:
                    px.Image = Properties.Resources._1;
                    break;
                case 2:
                    px.Image = Properties.Resources._2;
                    break;
                case 3:
                    px.Image = Properties.Resources._3;
                    break;
                case 4:
                    px.Image = Properties.Resources._4;
                    break;
                case 5:
                    px.Image = Properties.Resources._5;
                    break;
                case 6:
                    px.Image = Properties.Resources._6;
                    break;
            }
            /*px.Image = Image.FromFile(@"C:\Users\Nutty\OneDrive - kmutnb.ac.th\Desktop\Group1_SuperSnakesAndLadders\SuperSnakesAndLadders\Resources\" + ndic.ToString() + ".jpeg");
            px.SizeMode = PictureBoxSizeMode.StretchImage;*/
            return PointDice;

        }
        public static int rolldic(PictureBox px)
        {
            Random rand = new Random();
            int PointDice = rand.Next(1, 7);
            switch (PointDice)
            {
                case 1:
                    px.Image = Properties.Resources._1;
                    break;
                case 2:
                    px.Image = Properties.Resources._2;
                    break;
                case 3:
                    px.Image = Properties.Resources._3;
                    break;
                case 4:
                    px.Image = Properties.Resources._4;
                    break;
                case 5:
                    px.Image = Properties.Resources._5;
                    break;
                case 6:
                    px.Image = Properties.Resources._6;
                    break;
            }
            /*px.Image = Image.FromFile(@"C:\Users\Nutty\OneDrive - kmutnb.ac.th\Desktop\Group1_SuperSnakesAndLadders\SuperSnakesAndLadders\Resources\" + ndic.ToString() + ".jpeg");
            px.SizeMode = PictureBoxSizeMode.StretchImage;*/
            return PointDice;
            
        }
    }
}
