﻿namespace SuperSnakesAndLadders
{
    partial class FormGameTest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.buttonRollBot = new System.Windows.Forms.Button();
            this.buttonRoll = new System.Windows.Forms.Button();
            this.panelMap = new System.Windows.Forms.Panel();
            this.PlayerCom = new System.Windows.Forms.PictureBox();
            this.PlayerHuman = new System.Windows.Forms.PictureBox();
            this.textRollHuman = new System.Windows.Forms.TextBox();
            this.textRollBot = new System.Windows.Forms.TextBox();
            this.labelName = new System.Windows.Forms.Label();
            this.panelMap.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PlayerCom)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PlayerHuman)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Showcard Gothic", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(719, 330);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(196, 42);
            this.label1.TabIndex = 9;
            this.label1.Text = "Computer";
            // 
            // buttonRollBot
            // 
            this.buttonRollBot.BackColor = System.Drawing.Color.Blue;
            this.buttonRollBot.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonRollBot.Font = new System.Drawing.Font("Showcard Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonRollBot.ForeColor = System.Drawing.Color.Yellow;
            this.buttonRollBot.Location = new System.Drawing.Point(735, 554);
            this.buttonRollBot.Name = "buttonRollBot";
            this.buttonRollBot.Size = new System.Drawing.Size(166, 54);
            this.buttonRollBot.TabIndex = 7;
            this.buttonRollBot.Text = "Roll";
            this.buttonRollBot.UseVisualStyleBackColor = false;
            this.buttonRollBot.Click += new System.EventHandler(this.buttonRollBot_Click);
            // 
            // buttonRoll
            // 
            this.buttonRoll.BackColor = System.Drawing.Color.Red;
            this.buttonRoll.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonRoll.Font = new System.Drawing.Font("Showcard Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonRoll.ForeColor = System.Drawing.Color.Yellow;
            this.buttonRoll.Location = new System.Drawing.Point(735, 259);
            this.buttonRoll.Name = "buttonRoll";
            this.buttonRoll.Size = new System.Drawing.Size(166, 54);
            this.buttonRoll.TabIndex = 8;
            this.buttonRoll.Text = "Roll";
            this.buttonRoll.UseVisualStyleBackColor = false;
            this.buttonRoll.Click += new System.EventHandler(this.buttonRoll_Click);
            // 
            // panelMap
            // 
            this.panelMap.BackgroundImage = global::SuperSnakesAndLadders.Properties.Resources.แผนที่_1;
            this.panelMap.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panelMap.Controls.Add(this.PlayerCom);
            this.panelMap.Controls.Add(this.PlayerHuman);
            this.panelMap.Location = new System.Drawing.Point(40, 32);
            this.panelMap.Name = "panelMap";
            this.panelMap.Size = new System.Drawing.Size(629, 576);
            this.panelMap.TabIndex = 4;
            // 
            // PlayerCom
            // 
            this.PlayerCom.BackColor = System.Drawing.Color.Transparent;
            this.PlayerCom.BackgroundImage = global::SuperSnakesAndLadders.Properties.Resources.PlayerCompu;
            this.PlayerCom.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PlayerCom.Location = new System.Drawing.Point(23, 526);
            this.PlayerCom.Name = "PlayerCom";
            this.PlayerCom.Size = new System.Drawing.Size(21, 34);
            this.PlayerCom.TabIndex = 0;
            this.PlayerCom.TabStop = false;
            // 
            // PlayerHuman
            // 
            this.PlayerHuman.BackColor = System.Drawing.Color.Transparent;
            this.PlayerHuman.BackgroundImage = global::SuperSnakesAndLadders.Properties.Resources.PlayerHuman;
            this.PlayerHuman.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PlayerHuman.Location = new System.Drawing.Point(23, 526);
            this.PlayerHuman.Name = "PlayerHuman";
            this.PlayerHuman.Size = new System.Drawing.Size(21, 34);
            this.PlayerHuman.TabIndex = 0;
            this.PlayerHuman.TabStop = false;
            // 
            // textRollHuman
            // 
            this.textRollHuman.Font = new System.Drawing.Font("Showcard Gothic", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textRollHuman.Location = new System.Drawing.Point(739, 184);
            this.textRollHuman.Name = "textRollHuman";
            this.textRollHuman.Size = new System.Drawing.Size(162, 41);
            this.textRollHuman.TabIndex = 10;
            // 
            // textRollBot
            // 
            this.textRollBot.Font = new System.Drawing.Font("Showcard Gothic", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textRollBot.Location = new System.Drawing.Point(735, 490);
            this.textRollBot.Name = "textRollBot";
            this.textRollBot.Size = new System.Drawing.Size(162, 41);
            this.textRollBot.TabIndex = 10;
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Font = new System.Drawing.Font("Showcard Gothic", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelName.Location = new System.Drawing.Point(754, 67);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(106, 42);
            this.labelName.TabIndex = 11;
            this.labelName.Text = "Name";
            // 
            // FormGameTest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::SuperSnakesAndLadders.Properties.Resources.background;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(954, 640);
            this.Controls.Add(this.labelName);
            this.Controls.Add(this.textRollBot);
            this.Controls.Add(this.textRollHuman);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonRollBot);
            this.Controls.Add(this.buttonRoll);
            this.Controls.Add(this.panelMap);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Name = "FormGameTest";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormGameTest";
            this.Load += new System.EventHandler(this.FormGameTest_Load);
            this.panelMap.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.PlayerCom)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PlayerHuman)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonRollBot;
        private System.Windows.Forms.Button buttonRoll;
        private System.Windows.Forms.Panel panelMap;
        private System.Windows.Forms.PictureBox PlayerCom;
        private System.Windows.Forms.PictureBox PlayerHuman;
        private System.Windows.Forms.TextBox textRollHuman;
        private System.Windows.Forms.TextBox textRollBot;
        private System.Windows.Forms.Label labelName;
    }
}