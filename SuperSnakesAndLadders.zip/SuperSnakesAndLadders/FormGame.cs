﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SuperSnakesAndLadders
{
    public partial class FormGame : Form
    {
        
        private Dice _myDice = null;

        private Board _myBoard = new Board(18, 431);
        private GameController _myBot = new GameController(18, 431);
        public string txt;
        private SoundPlayer _playerWalk = null;
        private SoundPlayer _playerWin = null;
        private Ladder _myLadder = new Ladder(18, 431);
        private Snake _mySnake = new Snake(18, 431);
        public FormGame()
        {
            Application.OpenForms["FormName"].Hide();
            _playerWalk = new SoundPlayer(Properties.Resources.กระโดด);
            _playerWin = new SoundPlayer(Properties.Resources.cheer_up_);
            InitializeComponent();
            
        }
        
        private void buttonRoll_Click(object sender, EventArgs e)
        {
            int x, y, a, b;
            int dices = Dice.rolldic(pictureDice);
            _myBoard.ndice(dices);
            int numDice = _myBoard.NumDice;
            if (buttonRollBot.Enabled = true)
            {
                if (numDice == 7)
                {
                    _myLadder.podice2(25);
                    a = _myLadder.pox;
                    b = _myLadder.poy;
                    PlayerHuman.Location = new Point(a, b);
                    _myBoard.n2dice(25);
                }
                else if (numDice == 8)
                {
                    _myLadder.podice2(85);
                    a = _myLadder.pox;
                    b = _myLadder.poy;
                    PlayerHuman.Location = new Point(a, b);
                    _myBoard.n2dice(85);
                }
                else if (numDice == 19)
                {
                    _myLadder.podice2(65);
                    a = _myLadder.pox;
                    b = _myLadder.poy;
                    PlayerHuman.Location = new Point(a, b);
                    _myBoard.n2dice(65);
                }
                else if (numDice == 42)
                {
                    _myLadder.podice2(98);
                    a = _myLadder.pox;
                    b = _myLadder.poy;
                    PlayerHuman.Location = new Point(a, b);
                    _myBoard.n2dice(98);
                }
                else if (numDice == 70)
                {
                    _myLadder.podice2(92);
                    a = _myLadder.pox;
                    b = _myLadder.poy;
                    PlayerHuman.Location = new Point(a, b);
                    _myBoard.n2dice(92);
                }
                //งู
                else if (numDice == 29)
                {
                    _mySnake.podice2(10);
                    a = _mySnake.pox;
                    b = _mySnake.poy;
                    PlayerHuman.Location = new Point(a, b);
                    _myBoard.n2dice(10);
                }
                else if (numDice == 40)
                {
                    _mySnake.podice2(21);
                    a = _mySnake.pox;
                    b = _mySnake.poy;
                    PlayerHuman.Location = new Point(a, b);
                    _myBoard.n2dice(21);
                }
                else if (numDice == 52)
                {
                    _mySnake.podice2(15);
                    a = _mySnake.pox;
                    b = _mySnake.poy;
                    PlayerHuman.Location = new Point(a, b);
                    _myBoard.n2dice(15);
                }
                else if (numDice == 93)
                {
                    _mySnake.podice2(18);
                    a = _mySnake.pox;
                    b = _mySnake.poy;
                    PlayerHuman.Location = new Point(a, b);
                    _myBoard.n2dice(18);
                }
                else if (numDice == 81)
                {
                    _mySnake.podice2(43);
                    a = _mySnake.pox;
                    b = _mySnake.poy;
                    PlayerHuman.Location = new Point(a, b);
                    _myBoard.n2dice(43);
                }
                else if (numDice == 100 || numDice > 100)
                {
                    x = _myBoard.PositionX;
                    y = _myBoard.PositionY;
                    PlayerHuman.Location = new Point(x, y);

                    FormWin win = new FormWin();
                    win.txt = labelName.Text;
                    win.Show();
                    _playerWin.Play();
                    
                }
                else
                {
                    x = _myBoard.PositionX;
                    y = _myBoard.PositionY;
                    PlayerHuman.Location = new Point(x, y);
                    _playerWalk.Play();
                }

                buttonRoll.Enabled = false;
                
            }
            buttonRollBot.PerformClick();
            
        }

        private void FormGame_Load(object sender, EventArgs e)
        {
            _myDice = new Dice();
            buttonRollBot.Enabled = false;
            labelName.Text = txt;

            /*FormName formName = new FormName();
            
            TextBox tbx = (TextBox)formName.Controls["textName"];
            _mygameController.Name = tbx.Text;*/
        } 

        private void PlayerHuman_Click(object sender, EventArgs e)
        {

        }

        private void buttonRollBot_Click(object sender, EventArgs e)
        {
            
            int x, y, a, b;
            int dices = Dice.rolldic(pictureDiceBot);
            _myBot.ndice(dices);
            int numDice = _myBot.NumDice;
            if (buttonRoll.Enabled = true)
            {
                if (numDice == 7)
                {
                    _myLadder.podice2(25);
                    a = _myLadder.pox;
                    b = _myLadder.poy;
                    PlayerCom.Location = new Point(a, b);
                    _myBot.n2dice(25);
                }
                else if (numDice == 8)
                {
                    _myLadder.podice2(85);
                    a = _myLadder.pox;
                    b = _myLadder.poy;
                    PlayerCom.Location = new Point(a, b);
                    _myBot.n2dice(85);
                }
                else if (numDice == 19)
                {
                    _myLadder.podice2(65);
                    a = _myLadder.pox;
                    b = _myLadder.poy;
                    PlayerCom.Location = new Point(a, b);
                    _myBot.n2dice(65);
                }
                else if (numDice == 42)
                {
                    _myLadder.podice2(98);
                    a = _myLadder.pox;
                    b = _myLadder.poy;
                    PlayerCom.Location = new Point(a, b);
                    _myBot.n2dice(98);
                }
                else if (numDice == 70)
                {
                    _myLadder.podice2(92);
                    a = _myLadder.pox;
                    b = _myLadder.poy;
                    PlayerCom.Location = new Point(a, b);
                    _myBot.n2dice(92);
                }
                //งู
                else if (numDice == 29)
                {
                    _mySnake.podice2(10);
                    a = _mySnake.pox;
                    b = _mySnake.poy;
                    PlayerCom.Location = new Point(a, b);
                    _myBot.n2dice(10);
                }
                else if (numDice == 40)
                {
                    _mySnake.podice2(21);
                    a = _mySnake.pox;
                    b = _mySnake.poy;
                    PlayerCom.Location = new Point(a, b);
                    _myBot.n2dice(21);
                }
                else if (numDice == 52)
                {
                    _mySnake.podice2(15);
                    a = _mySnake.pox;
                    b = _mySnake.poy;
                    PlayerCom.Location = new Point(a, b);
                    _myBot.n2dice(15);
                }
                else if (numDice == 93)
                {
                    _mySnake.podice2(18);
                    a = _mySnake.pox;
                    b = _mySnake.poy;
                    PlayerCom.Location = new Point(a, b);
                    _myBot.n2dice(18);
                }
                else if (numDice == 81)
                {
                    _mySnake.podice2(43);
                    a = _mySnake.pox;
                    b = _mySnake.poy;
                    PlayerCom.Location = new Point(a, b);
                    _myBot.n2dice(43);
                }
                else if(numDice == 100 ||  numDice > 100)
                {
                    x = _myBot.PositionX;
                    y = _myBot.PositionY;
                    PlayerCom.Location = new Point(x, y);
                    FormGameOver gameOver = new FormGameOver();
                    gameOver.Show();

                }
                else
                {
                    _playerWalk.Play();
                    x = _myBot.PositionX;
                    y = _myBot.PositionY;
                    PlayerCom.Location = new Point(x, y);
                }
                buttonRollBot.Enabled = false;
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            
        }

        /*FormName _MyName = new FormName();
        public string username { get; set; }

        public string UserName(string name)
        {
            username = name;
            return username;
        }
        public static string Encryption(string input, int key)
        {
            string output = string.Empty;

            foreach (char ch in input)
                output += cipher(ch, key);
            return output;
        }

        public static string Decryption(string input, int key)
        {
            return Encryption(input, 26 - key);
        }

        public static char cipher(char ch, int key)
        {
            if (!char.IsLetter(ch))
            {
                return ch;
            }

            char d = char.IsUpper(ch) ? 'A' : 'a';
            return (char)((((ch + key) - d) % 26) + d);
        }

        private void HighScoreGameWin()
        {
            Win winner = new Win();
            winner.Show();
            string username = _MyName.Name;
            int key = 13;
            string ciphername = Encryption(username, key);
            string filepath = @"C:\Users\Nutty\OneDrive - kmutnb.ac.th\Desktop\Group1_Jumping_Frog\Highscore.txt";

            string text = File.ReadAllText(filepath);
            //string[] texts = text.Split(new[] { ", " }, StringSplitOptions.RemoveEmptyEntries);
            StreamWriter sw = File.CreateText(filepath);
            string name = ciphername;
            sw.Write(name);
            sw.Close();

            Application.Exit();
        }*/
    }
}