﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SuperSnakesAndLadders
{
    public partial class FormWinTest : Form
    {
        public String txt;
        private SoundPlayer _playerWin = null;
        public FormWinTest()
        {
            InitializeComponent();
            Application.OpenForms["FormGameTest"].Hide();
            _playerWin = new SoundPlayer(Properties.Resources.cheer_up_);

        }

        private void buttonEnd_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void buttonPlayAgain_Click(object sender, EventArgs e)
        {
            FormNameTest name = new FormNameTest();
            name.Show();
        }

        private void FormWinTest_Load(object sender, EventArgs e)
        {
            labelName.Text = txt;
            _playerWin.Play();
        }
    }
}
