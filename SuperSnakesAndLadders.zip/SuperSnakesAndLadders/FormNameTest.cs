﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SuperSnakesAndLadders
{
    public partial class FormNameTest : Form
    {
        
        public FormNameTest()
        {
            InitializeComponent();
            Application.OpenForms["FormPlay"].Hide();
        }

        private void FormName_Load(object sender, EventArgs e)
        {
            /*textName.Text = _name;*/
        }

        private void buttonGo_Click(object sender, EventArgs e)
        {
            if (textName.Text == "" || int.TryParse(textName.Text, out int x))
            {
                MessageBox.Show("กรุณากรอกชื่อเป็นตัวอักษรเท่านั้น");
                textName.Text = "";
            }
            else
            {

               FormGameTest game = new FormGameTest();
                game.txt = textName.Text;
                game.Show();
            }
            return;
        }

        private void buttonGo_Click_1(object sender, EventArgs e)
        {
            if (textName.Text == "" || int.TryParse(textName.Text, out int x))
            {
                MessageBox.Show("กรุณากรอกชื่อเป็นตัวอักษรเท่านั้น");
                textName.Text = "";
            }
            else
            {

                FormGameTest game = new FormGameTest();
                game.txt = textName.Text;
                game.Show();
            }
            return;
        }
    }
}
