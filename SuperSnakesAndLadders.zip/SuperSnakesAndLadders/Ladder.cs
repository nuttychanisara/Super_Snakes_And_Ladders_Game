﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SuperSnakesAndLadders
{
    class Ladder
    {
        private int _pox;
        private int _poy;
        private int _pod;
        private int _poox;
        private int _pooy;
        public int pod { get { return _pod; } set { _pod = value; } }
        public int pox { get { return _pox; } set { _pox = value; } }
        public int poy { get { return _poy; } set { _poy = value; } }
        public int poox { get { return _poox; } set { _poox = value; } }
        public int pooy { get { return _pooy; } set { _pooy = value; } }
        public Ladder() { }

        public Ladder(int ipoox, int ipooy)
        {
            poox = ipoox;
            pooy = ipooy;

        }
        public void podice2(int y)
        {
            pod = y;
            qmove();
        }
        /*public void podiceL2(int y)
        {
            pod = y;
            qmove2();
        }*/
        public void qmove()
        {
            if (pod == 25)
            {
                pox = poox + 46 * 4;
                poy = pooy - 47 * 2;
            }
            else if (pod == 85)
            {
                pox = poox + 46 * 4;
                poy = pooy - 47 * 8;
            }
            else if (pod == 65)
            {
                pox = poox + 46 * 4;
                poy = pooy - 47 * 6;
            }
            else if (pod == 98)
            {
                pox = poox + 46 * 2;
                poy = pooy - 47 * 9;
            }
            else if (pod == 92)
            {
                pox = poox + 46 * 8;
                poy = pooy - 47 * 9;
            }

        }
        /*public void qmove2()
        {
            if (pod == 56)
            {
                pox = poox + 46 * 4;
                poy = pooy - 47 * 5;
            }
            else if (pod == 33)
            {
                pox = poox + 46 * 7;
                poy = pooy - 47 * 3;
            }
            else if (pod == 80)
            {
                pox = poox + 46;
                poy = pooy - 47 * 7;
            }
            else if (pod == 99)
            {
                pox = poox + 46;
                poy = pooy - 47 * 9;
            }
            else if (pod == 89)
            {
                pox = poox + 46 * 8;
                poy = pooy - 47 * 8;
            }

        }*/
    }
}

