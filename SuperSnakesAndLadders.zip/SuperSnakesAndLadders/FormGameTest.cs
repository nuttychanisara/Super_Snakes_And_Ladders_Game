﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SuperSnakesAndLadders
{
    public partial class FormGameTest : Form
    {
        private Dice _myDice = null;
        private Board _myBoard = new Board(18, 431);
        private GameController _myBot = new GameController(18, 431);
        public string txt;
        private Ladder _myLadder = new Ladder(18, 431);
        private Snake _mySnake = new Snake(18, 431);
        private SoundPlayer _playerLadder = null;
        private SoundPlayer _playerSnake = null;
        private SoundPlayer _playerWalk = null;

        public FormGameTest()
        {
            Application.OpenForms["FormNameTest"].Hide();
            InitializeComponent();
            _playerLadder = new SoundPlayer(Properties.Resources.เดินขึ้นบันได);
            _playerSnake = new SoundPlayer(Properties.Resources.เสียงตกลง);
            _playerWalk = new SoundPlayer(Properties.Resources.กระโดด);
        }

        private void buttonRoll_Click(object sender, EventArgs e)
        {
            int PlayerWalk = Convert.ToInt32(textRollHuman.Text);
            _myBoard.ndice(PlayerWalk);
            int numDice = _myBoard.NumDice;

            int x, y, a, b;
            if (buttonRollBot.Enabled = true)
            {
                if (numDice == 7)
                {
                    
                    _myLadder.podice2(25);
                    a = _myLadder.pox;
                    b = _myLadder.poy;
                    PlayerHuman.Location = new Point(a, b);
                    _myBoard.n2dice(25);
                    
                }
                else if (numDice == 8)
                {
                    _myLadder.podice2(85);
                    a = _myLadder.pox;
                    b = _myLadder.poy;
                    PlayerHuman.Location = new Point(a, b);
                    _myBoard.n2dice(85);
                }
                else if (numDice == 19)
                {
                    _myLadder.podice2(65);
                    a = _myLadder.pox;
                    b = _myLadder.poy;
                    PlayerHuman.Location = new Point(a, b);
                    _myBoard.n2dice(65);
                }
                else if (numDice == 42)
                {
                    _myLadder.podice2(98);
                    a = _myLadder.pox;
                    b = _myLadder.poy;
                    PlayerHuman.Location = new Point(a, b);
                    _myBoard.n2dice(98);
                }
                else if (numDice == 70)
                {
                    _myLadder.podice2(92);
                    a = _myLadder.pox;
                    b = _myLadder.poy;
                    PlayerHuman.Location = new Point(a, b);
                    _myBoard.n2dice(92);
                }
                //งู
                else if (numDice == 29)
                {
                    _mySnake.podice2(10);
                    a = _mySnake.pox;
                    b = _mySnake.poy;
                    PlayerHuman.Location = new Point(a, b);
                    _myBoard.n2dice(10);
                }
                else if (numDice == 40)
                {
                    _mySnake.podice2(21);
                    a = _mySnake.pox;
                    b = _mySnake.poy;
                    PlayerHuman.Location = new Point(a, b);
                    _myBoard.n2dice(21);
                }
                else if (numDice == 52)
                {
                    _mySnake.podice2(15);
                    a = _mySnake.pox;
                    b = _mySnake.poy;
                    PlayerHuman.Location = new Point(a, b);
                    _myBoard.n2dice(15);
                }
                else if (numDice == 93)
                {
                    _mySnake.podice2(18);
                    a = _mySnake.pox;
                    b = _mySnake.poy;
                    PlayerHuman.Location = new Point(a, b);
                    _myBoard.n2dice(18);
                }
                else if (numDice == 81)
                {
                    _mySnake.podice2(43);
                    a = _mySnake.pox;
                    b = _mySnake.poy;
                    PlayerHuman.Location = new Point(a, b);
                    _myBoard.n2dice(43);
                }
                else if (numDice == 100 || numDice > 100)
                {
                    x = _myBoard.PositionX;
                    y = _myBoard.PositionY;
                    PlayerHuman.Location = new Point(x, y);

                    FormWinTest win = new FormWinTest();
                    win.txt = labelName.Text;
                    win.Show();
                }
                else
                {
                    _playerWalk.Play();
                    x = _myBoard.PositionX;
                    y = _myBoard.PositionY;
                    PlayerHuman.Location = new Point(x, y);
                }

                buttonRoll.Enabled = false;

            }
            buttonRollBot.PerformClick();
        }

        private void buttonRollBot_Click(object sender, EventArgs e)
        {
            int Bot = Convert.ToInt32(textRollBot.Text);
            _myBot.ndice(Bot);
            int numDice = _myBot.NumDice; 
            int x, y, a, b;
            
            if (buttonRoll.Enabled = true)
            {
                if (numDice == 7)
                {
                    _myLadder.podice2(25);
                    a = _myLadder.pox;
                    b = _myLadder.poy;
                    PlayerCom.Location = new Point(a, b);
                    _myBot.n2dice(25);
                }
                else if (numDice == 8)
                {
                    _myLadder.podice2(85);
                    a = _myLadder.pox;
                    b = _myLadder.poy;
                    PlayerCom.Location = new Point(a, b);
                    _myBot.n2dice(85);
                }
                else if (numDice == 19)
                {
                    _myLadder.podice2(65);
                    a = _myLadder.pox;
                    b = _myLadder.poy;
                    PlayerCom.Location = new Point(a, b);
                    _myBot.n2dice(65);
                }
                else if (numDice == 42)
                {
                    _myLadder.podice2(98);
                    a = _myLadder.pox;
                    b = _myLadder.poy;
                    PlayerCom.Location = new Point(a, b);
                    _myBot.n2dice(98);
                }
                else if (numDice == 70)
                {
                    _myLadder.podice2(92);
                    a = _myLadder.pox;
                    b = _myLadder.poy;
                    PlayerCom.Location = new Point(a, b);
                    _myBot.n2dice(92);
                }
                //งู
                else if (numDice == 29)
                {
                    _mySnake.podice2(10);
                    a = _mySnake.pox;
                    b = _mySnake.poy;
                    PlayerCom.Location = new Point(a, b);
                    _myBot.n2dice(10);
                }
                else if (numDice == 40)
                {
                    _mySnake.podice2(21);
                    a = _mySnake.pox;
                    b = _mySnake.poy;
                    PlayerCom.Location = new Point(a, b);
                    _myBot.n2dice(21);
                }
                else if (numDice == 52)
                {
                    _mySnake.podice2(15);
                    a = _mySnake.pox;
                    b = _mySnake.poy;
                    PlayerCom.Location = new Point(a, b);
                    _myBot.n2dice(15);
                }
                else if (numDice == 93)
                {
                    _mySnake.podice2(18);
                    a = _mySnake.pox;
                    b = _mySnake.poy;
                    PlayerCom.Location = new Point(a, b);
                    _myBot.n2dice(18);
                }
                else if (numDice == 81)
                {
                    _mySnake.podice2(43);
                    a = _mySnake.pox;
                    b = _mySnake.poy;
                    PlayerCom.Location = new Point(a, b);
                    _myBot.n2dice(43);
                }
                else if (numDice == 100 || numDice > 100)
                {
                    x = _myBot.PositionX;
                    y = _myBot.PositionY;
                    PlayerCom.Location = new Point(x, y);
                    FormGameOverTest gameOver = new FormGameOverTest();
                    gameOver.Show();

                }
                else
                {
                    _playerWalk.Play();
                    x = _myBot.PositionX;
                    y = _myBot.PositionY;
                    PlayerCom.Location = new Point(x, y);
                }
                buttonRollBot.Enabled = false;
            }
        }

        private void FormGameTest_Load(object sender, EventArgs e)
        {
            _myDice = new Dice();
            buttonRollBot.Enabled = false;
            labelName.Text = txt;
        }
    }
}
