﻿namespace SuperSnakesAndLadders
{
    partial class FormGame
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonRoll = new System.Windows.Forms.Button();
            this.labelName = new System.Windows.Forms.Label();
            this.buttonRollBot = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureDiceBot = new System.Windows.Forms.PictureBox();
            this.pictureDice = new System.Windows.Forms.PictureBox();
            this.panelMap = new System.Windows.Forms.Panel();
            this.PlayerCom = new System.Windows.Forms.PictureBox();
            this.PlayerHuman = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureDiceBot)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureDice)).BeginInit();
            this.panelMap.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PlayerCom)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PlayerHuman)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonRoll
            // 
            this.buttonRoll.BackColor = System.Drawing.Color.Red;
            this.buttonRoll.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonRoll.Font = new System.Drawing.Font("Showcard Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonRoll.ForeColor = System.Drawing.Color.Yellow;
            this.buttonRoll.Location = new System.Drawing.Point(726, 259);
            this.buttonRoll.Name = "buttonRoll";
            this.buttonRoll.Size = new System.Drawing.Size(166, 54);
            this.buttonRoll.TabIndex = 2;
            this.buttonRoll.Text = "Roll";
            this.buttonRoll.UseVisualStyleBackColor = false;
            this.buttonRoll.Click += new System.EventHandler(this.buttonRoll_Click);
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Font = new System.Drawing.Font("Showcard Gothic", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelName.Location = new System.Drawing.Point(754, 32);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(106, 42);
            this.labelName.TabIndex = 3;
            this.labelName.Text = "Name";
            // 
            // buttonRollBot
            // 
            this.buttonRollBot.BackColor = System.Drawing.Color.Blue;
            this.buttonRollBot.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonRollBot.Font = new System.Drawing.Font("Showcard Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonRollBot.ForeColor = System.Drawing.Color.Yellow;
            this.buttonRollBot.Location = new System.Drawing.Point(726, 554);
            this.buttonRollBot.Name = "buttonRollBot";
            this.buttonRollBot.Size = new System.Drawing.Size(166, 54);
            this.buttonRollBot.TabIndex = 2;
            this.buttonRollBot.Text = "Roll";
            this.buttonRollBot.UseVisualStyleBackColor = false;
            this.buttonRollBot.Click += new System.EventHandler(this.buttonRollBot_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Showcard Gothic", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(710, 330);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(196, 42);
            this.label1.TabIndex = 3;
            this.label1.Text = "Computer";
            // 
            // pictureDiceBot
            // 
            this.pictureDiceBot.BackColor = System.Drawing.SystemColors.Control;
            this.pictureDiceBot.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureDiceBot.Location = new System.Drawing.Point(726, 396);
            this.pictureDiceBot.Name = "pictureDiceBot";
            this.pictureDiceBot.Size = new System.Drawing.Size(159, 141);
            this.pictureDiceBot.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureDiceBot.TabIndex = 1;
            this.pictureDiceBot.TabStop = false;
            // 
            // pictureDice
            // 
            this.pictureDice.BackColor = System.Drawing.SystemColors.Control;
            this.pictureDice.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureDice.Location = new System.Drawing.Point(726, 90);
            this.pictureDice.Name = "pictureDice";
            this.pictureDice.Size = new System.Drawing.Size(159, 141);
            this.pictureDice.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureDice.TabIndex = 1;
            this.pictureDice.TabStop = false;
            // 
            // panelMap
            // 
            this.panelMap.BackgroundImage = global::SuperSnakesAndLadders.Properties.Resources.แผนที่_1;
            this.panelMap.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panelMap.Controls.Add(this.PlayerCom);
            this.panelMap.Controls.Add(this.PlayerHuman);
            this.panelMap.Location = new System.Drawing.Point(31, 32);
            this.panelMap.Name = "panelMap";
            this.panelMap.Size = new System.Drawing.Size(629, 576);
            this.panelMap.TabIndex = 0;
            // 
            // PlayerCom
            // 
            this.PlayerCom.BackColor = System.Drawing.Color.Transparent;
            this.PlayerCom.BackgroundImage = global::SuperSnakesAndLadders.Properties.Resources.PlayerCompu;
            this.PlayerCom.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PlayerCom.Location = new System.Drawing.Point(23, 526);
            this.PlayerCom.Name = "PlayerCom";
            this.PlayerCom.Size = new System.Drawing.Size(21, 34);
            this.PlayerCom.TabIndex = 0;
            this.PlayerCom.TabStop = false;
            this.PlayerCom.Click += new System.EventHandler(this.PlayerHuman_Click);
            // 
            // PlayerHuman
            // 
            this.PlayerHuman.BackColor = System.Drawing.Color.Transparent;
            this.PlayerHuman.BackgroundImage = global::SuperSnakesAndLadders.Properties.Resources.PlayerHuman;
            this.PlayerHuman.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PlayerHuman.Location = new System.Drawing.Point(23, 526);
            this.PlayerHuman.Name = "PlayerHuman";
            this.PlayerHuman.Size = new System.Drawing.Size(21, 34);
            this.PlayerHuman.TabIndex = 0;
            this.PlayerHuman.TabStop = false;
            this.PlayerHuman.Click += new System.EventHandler(this.PlayerHuman_Click);
            // 
            // FormGame
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::SuperSnakesAndLadders.Properties.Resources.background;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(954, 640);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.labelName);
            this.Controls.Add(this.buttonRollBot);
            this.Controls.Add(this.buttonRoll);
            this.Controls.Add(this.pictureDiceBot);
            this.Controls.Add(this.pictureDice);
            this.Controls.Add(this.panelMap);
            this.Name = "FormGame";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormGame";
            this.Load += new System.EventHandler(this.FormGame_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureDiceBot)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureDice)).EndInit();
            this.panelMap.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.PlayerCom)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PlayerHuman)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button buttonRoll;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.PictureBox pictureDice;
        private System.Windows.Forms.PictureBox PlayerHuman;
        private System.Windows.Forms.Panel panelMap;
        private System.Windows.Forms.PictureBox PlayerCom;
        private System.Windows.Forms.Button buttonRollBot;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureDiceBot;
    }
}