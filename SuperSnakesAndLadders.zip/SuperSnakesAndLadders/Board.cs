﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SuperSnakesAndLadders
{
    class Board
    {
        private int _posX;
        private int _posY;
        private int _posX2;
        private int _posY2;
        private int _nDice;
        private int _nMap;

        public int nMap
        {
            get { return _nMap; }
            set { _nMap = value; }
        }

        public int PositionX
        {
            get { return _posX; }
            set { _posX = value; }
        }
        public int PositionY
        {
            get { return _posY; }
            set { _posY = value; }
        }
        public int PositionX2
        {
            get { return _posX2; }
            set { _posX2 = value; }
        }
        public int PositionY2
        {
            get { return _posY2; }
            set { _posY2 = value; }
        }
        public int NumDice
        {
            get { return _nDice; }
            set { _nDice = value; }
        }

        public Board()
        {
            
            _nDice = 100;
        }
        public Board(int posX, int posY)
        {
            PositionX2 = posX;
            PositionY2 = posY;
            
            
        }
        
        public void ndice(int dic)
        {
            NumDice = _nDice + dic;
            playerMove();
        }
        public void n2dice(int dic2)
        {
            _nDice = dic2;
            playerMove();
        }

        

        public int MoveX(PictureBox px)
        {
            _posX = px.Location.X + 46;
            return _posX;
        }
        /*public static int Map(Panel panelMap)
        {
            Random random = new Random();
            int map = random.Next(1, 4);
            if(map == 1)
            {
                panelMap.BackgroundImage = Properties.Resources.แผนที่_1;
            }
            if (map == 2)
            {
                panelMap.BackgroundImage = Properties.Resources.แผนที่_2;
            }
            if (map == 3)
            {
                panelMap.BackgroundImage = Properties.Resources.แผนที่_3;
            }
            return map;
        }*/


        public void playerMove()
        {

            if (NumDice == 1)
            {
                PositionX = PositionX2;
                PositionY = PositionY2;
            }
            else if (NumDice == 2)
            {
                PositionX = PositionX2 + 46;
                PositionY = PositionY2;
            }
            else if (NumDice == 3)
            {
                PositionX = PositionX2 + 46 * 2;
                PositionY = PositionY2;
            }
            else if (NumDice == 4)
            {
                PositionX = PositionX2 + 46 * 3;
                PositionY = PositionY2;
            }
            else if (NumDice == 5)
            {
                PositionX = PositionX2 + 46 * 4;
                PositionY = PositionY2;
            }
            else if (NumDice == 6)
            {
                PositionX = PositionX2 + 46 * 5;
                PositionY = PositionY2;
            }
            else if (NumDice == 7)
            {
                PositionX = PositionX2 + 46 * 6;
                PositionY = PositionY2;
            }
            else if (NumDice == 8)
            {
                PositionX = PositionX2 + 46 * 7;
                PositionY = PositionY2;
            }
            else if (NumDice == 9)
            {
                PositionX = PositionX2 + 46 * 8;
                PositionY = PositionY2;
            }
            else if (NumDice == 10)
            {
                PositionX = PositionX2 + 46 * 9; 
                PositionY = PositionY2;
            }
            else if (NumDice == 11)
            {
                PositionX = PositionX2 + 46 * 9;
                PositionY = PositionY2 - 47;
            }
            else if (NumDice == 12)
            {
                PositionX = PositionX2 + 46 * 8;
                PositionY = PositionY2 - 47;
            }
            else if (NumDice == 13)
            {
                PositionX = PositionX2 + 46 * 7;
                PositionY = PositionY2 - 47;
            }
            else if (NumDice == 14)
            {
                PositionX = PositionX2 + 46 * 6;
                PositionY = PositionY2 - 47;
            }
            else if (NumDice == 15)
            {
                PositionX = PositionX2 + 46 * 5;
                PositionY = PositionY2 - 47;
            }
            else if (NumDice == 16)
            {
                PositionX = PositionX2 + 46 * 4;
                PositionY = PositionY2 - 47;
            }
            else if (NumDice == 17)
            {
                PositionX = PositionX2 + 46 * 3;
                PositionY = PositionY2 - 47;
            }
            else if (NumDice == 18)
            {
                PositionX = PositionX2 + 46 * 2;
                PositionY = PositionY2 - 47;
            }
            else if (NumDice == 19)
            {
                PositionX = PositionX2 + 46;
                PositionY = PositionY2 - 47;
            }
            else if (NumDice == 20)
            {
                PositionX = PositionX2;
                PositionY = PositionY2 - 47;
            }
            else if (NumDice == 21)
            {
                PositionX = PositionX2;
                PositionY = PositionY2 - 47 * 2;
            }
            else if (NumDice == 22)
            {
                PositionX = PositionX2 + 46;
                PositionY = PositionY2 - 47 * 2;
            }
            else if (NumDice == 23)
            {
                PositionX = PositionX2 + 46 * 2;
                PositionY = PositionY2 - 47 * 2;
            }
            else if (NumDice == 24)
            {
                PositionX = PositionX2 + 46 * 3;
                PositionY = PositionY2 - 47 * 2;
            }
            else if (NumDice == 25)
            {
                PositionX = PositionX2 + 46 * 4;
                PositionY = PositionY2 - 47 * 2;
            }
            else if (NumDice == 26)
            {
                PositionX = PositionX2 + 46 * 5;
                PositionY = PositionY2 - 47 * 2;
            }
            else if (NumDice == 27)
            {
                PositionX = PositionX2 + 46 * 6;
                PositionY = PositionY2 - 47 * 2;
            }
            else if (NumDice == 28)
            {
                PositionX = PositionX2 + 46 * 7;
                PositionY = PositionY2 - 47 * 2;
            }
            else if (NumDice == 29)
            {
                PositionX = PositionX2 + 46 * 8;
                PositionY = PositionY2 - 47 * 2;
            }
            else if (NumDice == 30)
            {
                PositionX = PositionX2 + 46 * 9;
                PositionY = PositionY2 - 47 * 2;
            }
            else if (NumDice == 31)
            {
                PositionX = PositionX2 + 46 * 9;
                PositionY = PositionY2 - 47 * 3;
            }
            else if (NumDice == 32)
            {
                PositionX = PositionX2 + 46 * 8;
                PositionY = PositionY2 - 47 * 3;
            }
            else if (NumDice == 33)
            {
                PositionX = PositionX2 + 46 * 7;
                PositionY = PositionY2 - 47 * 3;
            }
            else if (NumDice == 34)
            {
                PositionX = PositionX2 + 46 * 6;
                PositionY = PositionY2 - 47 * 3;
            }
            else if (NumDice == 35)
            {
                PositionX = PositionX2 + 46 * 5;
                PositionY = PositionY2 - 47 * 3;
            }
            else if (NumDice == 36)
            {
                PositionX = PositionX2 + 46 * 4;
                PositionY = PositionY2 - 47 * 3;
            }
            else if (NumDice == 37)
            {
                PositionX = PositionX2 + 46 * 3;
                PositionY = PositionY2 - 47 * 3;
            }
            else if (NumDice == 38)
            {
                PositionX = PositionX2 + 46 * 2;
                PositionY = PositionY2 - 47 * 3;
            }
            else if (NumDice == 39)
            {
                PositionX = PositionX2 + 46;
                PositionY = PositionY2 - 47 * 3;
            }
            else if (NumDice == 40)
            {
                PositionX = PositionX2;
                PositionY = PositionY2 - 47 * 3;
            }
            else if (NumDice == 41)
            {
                PositionX = PositionX2;
                PositionY = PositionY2 - 47 * 4;
            }
            else if (NumDice == 42)
            {
                PositionX = PositionX2 + 46;
                PositionY = PositionY2 - 47 * 4;
            }
            else if (NumDice == 43)
            {
                PositionX = PositionX2 + 46 * 2;
                PositionY = PositionY2 - 47 * 4;
            }
            else if (NumDice == 44)
            {
                PositionX = PositionX2 + 46 * 3;
                PositionY = PositionY2 - 47 * 4;
            }
            else if (NumDice == 45)
            {
                PositionX = PositionX2 + 46 * 4;
                PositionY = PositionY2 - 47 * 4;
            }
            else if (NumDice == 46)
            {
                PositionX = PositionX2 + 46 * 5;
                PositionY = PositionY2 - 47 * 4;
            }
            else if (NumDice == 47)
            {
                PositionX = PositionX2 + 46 * 6;
                PositionY = PositionY2 - 47 * 4;
            }
            else if (NumDice == 48)
            {
                PositionX = PositionX2 + 46 * 7;
                PositionY = PositionY2 - 47 * 4;
            }
            else if (NumDice == 49)
            {
                PositionX = PositionX2 + 46 * 8;
                PositionY = PositionY2 - 47 * 4;
            }
            else if (NumDice == 50)
            {
                PositionX = PositionX2 + 46 * 9;
                PositionY = PositionY2 - 47 * 4;
            }
            else if (NumDice == 51)
            {
                PositionX = PositionX2 + 46 * 9;
                PositionY = PositionY2 - 47 * 5;
            }
            else if (NumDice == 52)
            {
                PositionX = PositionX2 + 46 * 8;
                PositionY = PositionY2 - 47 * 5;
            }
            else if (NumDice == 53)
            {
                PositionX = PositionX2 + 46 * 7;
                PositionY = PositionY2 - 47 * 5;
            }
            else if (NumDice == 54)
            {
                PositionX = PositionX2 + 46 * 6;
                PositionY = PositionY2 - 47 * 5;
            }
            else if (NumDice == 55)
            {
                PositionX = PositionX2 + 46 * 5;
                PositionY = PositionY2 - 47 * 5;
            }
            else if (NumDice == 56)
            {
                PositionX = PositionX2 + 46 * 4;
                PositionY = PositionY2 - 47 * 5;
            }
            else if (NumDice == 57)
            {
                PositionX = PositionX2 + 46 * 3;
                PositionY = PositionY2 - 47 * 5;
            }
            else if (NumDice == 58)
            {
                PositionX = PositionX2 + 46 * 2;
                PositionY = PositionY2 - 47 * 5;
            }
            else if (NumDice == 59)
            {
                PositionX = PositionX2 + 46;
                PositionY = PositionY2 - 47 * 5;
            }
            else if (NumDice == 60)
            {
                PositionX = PositionX2;
                PositionY = PositionY2 - 47 * 5;
            }
            else if (_nDice == 61)
            {
                PositionX = PositionX2;
                PositionY = PositionY2 - 47 * 6;
            }
            else if (NumDice == 62)
            {
                PositionX = PositionX2 + 46;
                PositionY = PositionY2 - 47 * 6;
            }
            else if (NumDice == 63)
            {
                PositionX = PositionX2 + 46 * 2;
                PositionY = PositionY2 - 47 * 6;
            }
            else if (NumDice == 64)
            {
                PositionX = PositionX2 + 46 * 3;
                PositionY = PositionY2 - 47 * 6;
            }
            else if (NumDice == 65)
            {
                PositionX = PositionX2 + 46 * 4;
                PositionY = PositionY2 - 47 * 6;
            }
            else if (NumDice == 66)
            {
                PositionX = PositionX2 + 46 * 5;
                PositionY = PositionY2 - 47 * 6;
            }
            else if (NumDice == 67)
            {
                PositionX = PositionX2 + 46 * 6;
                PositionY = PositionY2 - 47 * 6;
            }
            else if (NumDice == 68)
            {
                PositionX = PositionX2 + 46 * 7;
                PositionY = PositionY2 - 47 * 6;
            }
            else if (NumDice == 69)
            {
                PositionX = PositionX2 + 46 * 8;
                PositionY = PositionY2 - 47 * 6;
            }
            else if (NumDice == 70)
            {
                PositionX = PositionX2 + 46 * 9;
                PositionY = PositionY2 - 47 * 6;
            }
            else if (NumDice == 71)
            {
                PositionX = PositionX2 + 46 * 9;
                PositionY = PositionY2 - 47 * 7;
            }
            else if (NumDice == 72)
            {
                PositionX = PositionX2 + 46 * 8;
                PositionY = PositionY2 - 47 * 7;
            }
            else if (NumDice == 73)
            {
                PositionX = PositionX2 + 46 * 7;
                PositionY = PositionY2 - 47 * 7;
            }
            else if (NumDice == 74)
            {
                PositionX = PositionX2 + 46 * 6;
                PositionY = PositionY2 - 47 * 7;
            }
            else if (NumDice == 75)
            {
                PositionX = PositionX2 + 46 * 5;
                PositionY = PositionY2 - 47 * 7;
            }
            else if (NumDice == 76)
            {
                PositionX = PositionX2 + 46 * 4;
                PositionY = PositionY2 - 47 * 7;
            }
            else if (NumDice == 77)
            {
                PositionX = PositionX2 + 46 * 3;
                PositionY = PositionY2 - 47 * 7;
            }
            else if (NumDice == 78)
            {
                PositionX = PositionX2 + 46 * 2;
                PositionY = PositionY2 - 47 * 7;
            }
            else if (NumDice == 79)
            {
                PositionX = PositionX2 + 46;
                PositionY = PositionY2 - 47 * 7;
            }
            else if (NumDice == 80)
            {
                PositionX = PositionX2;
                PositionY = PositionY2 - 47 * 7;
            }
            else if (NumDice == 81)
            {
                PositionX = PositionX2;
                PositionY = PositionY2 - 47 * 8;
            }
            else if (NumDice == 82)
            {
                PositionX = PositionX2 + 46;
                PositionY = PositionY2 - 47 * 8;
            }
            else if (NumDice == 83)
            {
                PositionX = PositionX2 + 46 * 2;
                PositionY = PositionY2 - 47 * 8;
            }
            else if (NumDice == 84)
            {
                PositionX = PositionX2 + 46 * 3;
                PositionY = PositionY2 - 47 * 8;
            }
            else if (NumDice == 85)
            {
                PositionX = PositionX2 + 46 * 4;
                PositionY = PositionY2 - 47 * 8;
            }
            else if (NumDice == 86)
            {
                PositionX = PositionX2 + 46 * 5;
                PositionY = PositionY2 - 47 * 8;
            }
            else if (NumDice == 87)
            {
                PositionX = PositionX2 + 46 * 6;
                PositionY = PositionY2 - 47 * 8;
            }
            else if (NumDice == 88)
            {
                PositionX = PositionX2 + 46 * 7;
                PositionY = PositionY2 - 47 * 8;
            }
            else if (NumDice == 89)
            {
                PositionX = PositionX2 + 46 * 8;
                PositionY = PositionY2 - 47 * 8;
            }
            else if (NumDice == 90)
            {
                PositionX = PositionX2 + 46 * 9;
                PositionY = PositionY2 - 47 * 8;
            }
            else if (NumDice == 91)
            {
                PositionX = PositionX2 + 46 * 9;
                PositionY = PositionY2 - 47 * 9;
            }
            else if (NumDice == 92)
            {
                PositionX = PositionX2 + 46 * 8;
                PositionY = PositionY2 - 47 * 9;
            }
            else if (NumDice == 93)
            {
                PositionX = PositionX2 + 46 * 7;
                PositionY = PositionY2 - 47 * 9;
            }
            else if (NumDice == 94)
            {
                PositionX = PositionX2 + 46 * 6;
                PositionY = PositionY2 - 47 * 9;
            }
            else if (NumDice == 95)
            {
                PositionX = PositionX2 + 46 * 5;
                PositionY = PositionY2 - 47 * 9;
            }
            else if (NumDice == 96)
            {
                PositionX = PositionX2 + 46 * 4;
                PositionY = PositionY2 - 47 * 9;
            }
            else if (NumDice == 97)
            {
                PositionX = PositionX2 + 46 * 3;
                PositionY = PositionY2 - 47 * 9;
            }
            else if (NumDice == 98)
            {
                PositionX = PositionX2 + 46 * 2;
                PositionY = PositionY2 - 47 * 9;
            }
            else if (NumDice == 99)
            {
                PositionX = PositionX2 + 46;
                PositionY = PositionY2 - 47 * 9;
            }
            else if(NumDice == 100 || NumDice > 100)
            {
                PositionX = PositionX2;
                PositionY = PositionY2 - 47 * 9;
            }
        }
        public int Dicemove(int DiceMove)
        {
            _posX = _posX - DiceMove;
            return _posX;
        }

    }
}
